package cn.jiguang.imui.messagelist.event;


public class OnTouchMsgListEvent {
}
