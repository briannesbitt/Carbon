package cn.jiguang.imui.messagelist.event;

public class StopPlayVoiceEvent {

    public StopPlayVoiceEvent() {
    }
}
