//
//  MessageEventCollectionViewCell.h
//  sampleObjectC
//
//  Created by oshumini on 2017/6/16.
//  Copyright © 2017年 HXHG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "sampleObjectC-Swift.h"

@interface MessageEventCollectionViewCell : UICollectionViewCell
- (void)presentCell:(NSString *)eventText;
@end
