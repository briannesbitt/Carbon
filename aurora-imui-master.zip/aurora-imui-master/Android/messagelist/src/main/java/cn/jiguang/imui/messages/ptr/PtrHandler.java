package cn.jiguang.imui.messages.ptr;


public interface PtrHandler {

    public void onRefreshBegin(PullToRefreshLayout layout);
}
