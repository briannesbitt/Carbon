package cn.jiguang.imui.chatinput.emoji;

/**
 * use XhsEmotionsKeyboard(https://github.com/w446108264/XhsEmoticonsKeyboard)
 * author: sj
 */
public class EmojiBean {
    public int icon;
    public String emoji;

    public EmojiBean(int icon, String emoji) {
        this.icon = icon;
        this.emoji = emoji;
    }
}