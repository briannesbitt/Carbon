package cn.jiguang.imui.chatinput.listener;

/**
 * Created by caiyaoguan on 2017/6/8.
 */

public interface OnClickEditTextListener {
    void onTouchEditText();
}
